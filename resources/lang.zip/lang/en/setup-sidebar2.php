<?php

return[
    'service-desk_language' => 'Servicedesk Configuration',
    'customization_language' => 'Customization',
    'template-form_language' => 'Template Form',
    'users-permissions_language' => 'Users & Permissions',
    'service-activation_language' => 'Service Activation',
    'setting-notifications_language' => 'Setting Notifications',
    'data-administration_language' => 'Data Administration',
    'chat_language' => 'Chat'
    
    ];