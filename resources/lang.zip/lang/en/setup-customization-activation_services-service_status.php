<?php

return[
    'title_language' => 'Status',
    
    'name_language' => 'Name',
    'desc_language' => 'Description',
    'new-data_language' => 'New Status',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'desc2_language' => 'Description',
    'desc3_language' => 'Description',
    'save_language' => 'Save',
    'cancel_language' => 'Cancel',
    
    'edit-data_language' => 'Edit Status',
    'name4_language' => 'Name',
    'name5_language' => 'Name',
    'desc4_language' => 'Description',
    'desc5_language' => 'Description',
    'save2_language' => 'Save',
    'cancel2_language' => 'Cancel'

  
    ];