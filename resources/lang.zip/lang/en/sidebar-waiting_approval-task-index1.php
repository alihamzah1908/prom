<?php

return[
    'task-type_language' => 'Task Type',
    'region_language' => 'Region',
    'search_language' => 'Search',
    'creation-time-from_language' => 'Creation time from',
    'to_language' => 'to',
    'completion-time-from_language' => 'Completion time from',
    'to2_language' => 'to',
    'refresh_language' => 'Refresh',
    'download_language' => 'Download',
    'task-status_language' => 'Task Status',
    'task-id_language' => 'Task ID',
    'title_language' => 'Title',
    'site-id_language' => 'Site ID',
    'creation-time_language' => 'Creation Time',
    'completion-time_language' => 'Completion Time',
    
    
    
    
    ];