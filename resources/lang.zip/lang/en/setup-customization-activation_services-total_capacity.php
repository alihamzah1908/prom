<?php

return[
    'title_language' => 'Total Capacity',
    'create_language' => 'Create',
    'name_language' => 'Name',
    'desc_language' => 'Description',
    'new-data_language' => 'New Total Capacity',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'desc2_language' => 'Description',
    'desc3_language' => 'Description',
    'save_language' => 'Save',
    'cancel_language' => 'Cancel',
    
    'edit-data_language' => 'Edit Total Capacity',
    'name4_language' => 'Name',
    'name5_language' => 'Name',
    'desc4_language' => 'Description',
    'desc5_language' => 'Description',
    'save2_language' => 'Save',
    'cancel2_language' => 'Cancel',
    
    'data_language' => 'Total Capacity',
    'name6_language' => 'Name',
    'name7-data_language' => 'Name',
    'message_language' => 'User will permanently be deleted!',
    'continue_language' => 'Continue?',
    'cancel3_language' => 'Cancel',
    'delete_language' => 'Delete'

  
    ];