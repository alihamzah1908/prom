<?php

return[
    'root-caused_language' => 'Root Caused',
    'new-root-caused_language' => 'New Root Caused',
    'name_language' => 'Name',
    'desc_language' => 'Description',
    'new-root-caused_language' => 'New Root Caused',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'desc2_language' => 'Description',
    'desc3_language' => 'Description',
    'create_language' => 'Create',
    'cancel_language' => 'Cancel',
    
    'ask_language' => 'Are you sure delete ',
    'notif_language' => 'This record and it`s details will be permanantly deleted!',
    'cancel2_language' => 'Cancel',
    'yes_language' => 'Yes!',
    'message_language' => 'Data has been deleted!'

    ];