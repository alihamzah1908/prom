<?php

return[
    'gps_language' => 'GPS',
    'select-site_language' => 'Select Site',
    'list_language' => 'LIST',
    'map_language' => 'MAP',
    'refresh_language' => 'Refresh',
    'search_language' => 'Search',
    'id_language' => 'ID',
    'technician_language' => 'Technician',
    'site_language' => 'Site',
    'latitude_language' => 'Latitude',
    'longitude_language' => 'Longitude',
    'last-update_language' => 'Last Update'
    
    
    ];