<?php

return[
    'roles_language' => 'Roles',
    'role-name_language' => 'Role Name',
    'role-name2_language' => 'Role Name',
    'as-admin_language' => 'As Admin',
    'access_language' => 'Access',
    'submit_language' => 'Submit',
    'back_language' => 'Back',

  
    ];