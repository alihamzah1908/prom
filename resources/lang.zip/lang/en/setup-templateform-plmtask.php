<?php

return[
    'reset-form_language' => 'Reset Form',
    
    'basic-information_language' => 'Basic Information',
    'site-id_language' => 'Site ID',
    'select-site_language' => 'Select Site',
    'task-category_language' => 'Task Category',
    'select-category_language' => 'Select Category',
    'task-sub-category_language' => 'Task Sub Category',
    'request-start-time_language' => 'Request Start Time',
    'request-completion_language' => 'Request Completion',
    'title_language' => 'Title',
    'subject_language' => 'Subject',
    'description_language' => 'Description',
    'description2_language' => 'Description',
    'technician_language' => 'Technician',
    'select-technician_language' => 'Select Technician',
    'site-information_language' => 'Site Information',
    'site-name_language' => 'Site Name',
    'site-address_language' => 'Site Address',
    'region-manager_language' => 'Region Manager',
    'manager-phone-no_language' => 'Manager Phone No',
    'region_language' => 'Region',
    'select-sub-category_language' => 'Select Sub Category'
  
    ];