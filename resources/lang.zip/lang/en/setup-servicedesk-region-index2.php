<?php

return[
    'regions_language' => 'Regions',
    'new-region_language' => 'New Region',
    'region-name_language' => 'Region Name',
    'desc_language' => 'Description',
    'new-region2_language' => 'New Region',
    'region-name2_language' => 'Region Name',
    'name_language' => 'Name',
    'desc2_language' => 'Description',
    'desc3_language' => 'Description',
    'create_language' => 'Create',
    'cancel_language' => 'Cancel',
    
    'ask_language' => 'Are you sure delete ',
    'notif_language' => 'This record and it`s details will be permanantly deleted!',
    'cancel2_language' => 'Cancel',
    'yes_language' => 'Yes!',
    'message_language' => 'Data has been deleted!'
    ];