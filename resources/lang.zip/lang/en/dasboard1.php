<?php

return[
    'dasboard_language' => 'DASBOARD',
    'task_language' => 'TASK',
    'layanan_language' => 'SERVICES',
    'site-entry_language' => 'SITE ENTRY',
    'permit-letter_language' => 'PERMIT_LETTER'
    
    ];