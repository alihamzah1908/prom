<?php

return[
    'reset-form_language' => 'Reset Form',
    'category_language' => 'Category',
    'select-category_language' => 'Select Category',
    'priority_language' => 'Priority',
    'select-priority_language' => 'Select Priority',
    'region_language' => 'Region',
    'select-region_language' => 'Select Region',
    'location-a_language' => 'Location A',
    'select-location_language' => 'Select Location',
    'description_language' => 'Description',
    'description2_language' => 'Description',
    'attacment_language' => 'Attacment',
    'change-attachment_language' => 'Change Attachment',
    'message_language' => '(Leave Empty to keep attachment as it is)',
    'work-time_language' => 'Work time',
    'request-start-time_language' => 'Request Start Time',
    'request-completion_language' => 'Request Completion',
    'work-day-result_language' => 'Work Day Result',
    'assign-to_language' => 'Assign To',
    'select-technician_language' => 'Select Technician',
    'down-time_language' => 'Down Time',
    'start-time_language' => 'Start Time',
    'finish-time_language' => 'Finish Time',
    'work-time-result_language' => 'Work Time Result'
  
    ];