<?php

return[
    'customer_language' => 'Customer',
    'new-customer_language' => 'New Customer',
    'id_language' => 'ID',
    'name_language' => 'Name',
    'email_language' => 'Email',
    'new-customer2_language' => 'New Customer',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'email2_language' => 'Email',
    'email3_language' => 'Email',
    'save_language' => 'Save',
    'close_language' => 'Close',
    
    'edit-customer_language' => 'Edit Customer',
    'name4_language' => 'Name',
    'name5_language' => 'Name',
    'email4_language' => 'Email',
    'email5_language' => 'Email',
    'save2_language' => 'Save',
    'close2_language' => 'Close',
    
    'delete_language' => 'Delete',
    'message_language' => 'Data will be deleted permanently',
    'continue_language' => 'Continue?',
    'close3_language' => 'Close',
    'ok_language' => 'OK'

  
    ];