<?php

return[
    'roles_language' => 'Roles',
    'new-role_language' => 'New Role',
    'role-name_language' => 'Role Name',
    'new-role2_language' => 'New Role',
    'name_language' => 'Name',
    'role-name2_language' => 'Role Name',
    'cancel_language' => 'Cancel',
    'save_language' => 'Save',
    'delete_language' => 'Delete',
    'message_language' => 'Data will be deleted permanently',
    'continue_language' => 'Continue?',

    'close_language' => 'Close',
    'ok_language' => 'OK',

  
    ];