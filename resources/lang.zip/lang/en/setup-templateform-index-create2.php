<?php

return[
    'template_language' => 'Template',
    'copy-from_language' => 'Copy From: ',
    'copy-template_language' => 'Copy Template',
    'template-name_language' => 'Template Name',
    'template-name2_language' => 'Template Name',
    'comments_language' => 'Comments',
    'comments2_language' => 'Comments',
    'elements_language' => 'Elements',
    'back_language' => 'Back',
    'save-template_language' => 'Save Template',
    'field-set_language' => 'Field Set',
    'field-id_language' => 'Field ID',
    'field-type_language' => 'Field Type',
    'field-name_language' => 'Field Name',
    'field-name2_language' => 'Field Name',
    'default-value_language' => 'Default value',
    'default-value2_language' => 'Default value',
    'close_language' => 'Close',
    'save_language' => 'Save'
    
    ];