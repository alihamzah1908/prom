<?php

return[
    'validator_language' => 'Validator Activation',
    'create_language' => 'Create',
    'region_language' => 'Region',
    'region2_language' => 'Region',
    'type_language' => 'Type',
    'validator2_language' => 'Validator I',
    'validator3_language' => 'Validator II',
    'validator10_language' => 'Validator III',
    
    'new-validator_language' => 'New Validator',
    'region3_language' => 'Region',
    'region4_language' => 'Region',
    'type2_language' => 'Type',
    'type3_language' => 'Task Type',
    'validator4_language' => 'Validator',
    'validator5_language' => 'Validator I',
    'select_language' => 'Select',
    'validator6_language' => 'Validator II',
    'select2_language' => 'Select',
    'validator11_language' => 'Validator II',
    'select6_language' => 'Select',
    'save_language' => 'Save',
    'close_language' => 'Close',
    
    'edit-validator_language' => 'Edit Validator',
    'region5_language' => 'Region',
    'region6_language' => 'Region',
    'type4_language' => 'Type',
    'type5_language' => 'Task Type',
    'validator7_language' => 'Validator',
    'validator8_language' => 'Validator I',
    'select3_language' => 'Select',
    'validator9_language' => 'Validator II',
    'select4_language' => 'Select',
    'validator12_language' => 'Validator II',
    'select5_language' => 'Select',
    'save2_language' => 'Save',
    'close2_language' => 'Close',
    
    'delete_language' => 'Delete',
    'message_language' => 'Data will be deleted permanently',
    'continue_language' => 'Continue?',
    'close3_language' => 'Close',
    'ok_language' => 'OK'

  
    ];