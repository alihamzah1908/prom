<?php

return[
    'site_language' => 'Site',
    'site-entry_language' => 'Site Entry',
    'permit-letter_language' => 'Permit Letter',
    'refresh_language' => 'Refresh',
    'search_language' => 'Search',
    'id_language' => 'ID',
    'status_language' => 'Status',
    'region_language' => 'Region',
    'site2_language' => 'Site',
    'time_language' => 'Time',
    'officer_language' => 'Officer',
    'created-by_language' => 'Created By',
    'id2_language' => 'ID',
    'activity-no_language' => 'Activity No',
    'site3_language' => 'Site',
    'applicant_language' => 'Applicant',
    'date-of-filing_language' => 'Date of filing',
    'status2_language' => 'Status'
    
    ];