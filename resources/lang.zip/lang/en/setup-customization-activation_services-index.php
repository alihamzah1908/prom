<?php

return[
    'title_language' => 'Service Activation Configuration',
    'cord_language' => 'Cord',
    'cid_language' => 'CID',
    'slot_language' => 'Slot',
    'shelf_language' => 'Shelf',
    'service-status_language' => 'Service Status',
    'status-collocation_language' => 'Status Collocation',
    'services_language' => 'Services',
    'total-capacity_language' => 'Total Capacity'

  
    ];