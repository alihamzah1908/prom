<?php

return[
    'status_language' => 'Status',
    'new-status_language' => 'New Status',
    'name_language' => 'Name',
    'desc_language' => 'Description',
    'group_language' => 'Group',
    'color_language' => 'Color',
    'message_language' => 'No data available',
    'new-status_language' => 'New Status',
    'status2_language' => 'Status',
    'status3_language' => 'Status',
    'color2_language' => 'Color',
    'color3_language' => 'Color',
    'type_language' => 'Type',
    'in-progress_language' => 'In Progress',
    'completed_language' => 'Completed',
    'stop-timer_language' => 'Stop Timer',
    'desc2_language' => 'Description',
    'desc3_language' => 'Description',
    'save_language' => 'Save',
    
    'edit-data_language' => 'Edit Data',
    'status4_language' => 'Status',
    'status5_language' => 'Status',
    'color4_language' => 'Color',
    'color5_language' => 'Color',
    'type2_language' => 'Type',
    'in-progress2_language' => 'In Progress',
    'completed2_language' => 'Completed',
    'stop-timer2_language' => 'Stop Timer',
    'desc4_language' => 'Description',
    'desc5_language' => 'Description',
    'save2_language' => 'Save',
    'cancel_language' => 'Cancel'
    
    
    
    
    
  
    ];