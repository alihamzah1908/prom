<?php

return[
    'priority_language' => 'Priority',
    'status_language' => 'Status',
    'root-case_language' => 'Root Case',
    'this-week_language' => 'This Week',
    'this-month_language' => 'This Month',
    'count-per-region_language' => 'Count per Region',
    'fo-link-frequency_language' => 'Fo link Frequency',
    'chart-mmtr_language' => 'Chart MMTR',
    
    
    ];