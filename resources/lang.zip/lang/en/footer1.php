<?php

return[
    'footer_language' => 'All rights reserved.'
    ];