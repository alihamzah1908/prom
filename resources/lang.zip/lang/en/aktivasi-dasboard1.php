<?php

return[
    'customers_language' => 'Customers',
    'status_language' => 'Status',
    'used-capacity_language' => 'Used Capacity',
    'capacity-1-gb_language' => 'Capacity 1 GB',
    'capacity-10-gb_language' => 'Capacity 10 GB',
    'this-week_language' => 'This Week',
    'this-month_language' => 'This Month',
    'count-per-region_language' => 'Count per Region',
    'count-per-segment_language' => 'Count per Segment',
    'capacity-per-region_language' => 'Capacity per Region'
    
    ];