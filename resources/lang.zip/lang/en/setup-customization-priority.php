<?php

return[
    'priority_language' => 'Priority',
    'new-priority_language' => 'New Priority',
    'name_language' => 'Name',
    'desc_language' => 'Description',
    'color_language' => 'Color',
    'message_language' => 'No data available',
    'new-priority2_language' => 'New Priority',
    'priority2_language' => 'Priority',
    'priority3_language' => 'Priority',
    'color2_language' => 'Color',
    'color3_language' => 'Color',
    'desc2_language' => 'Description',
    'desc3_language' => 'Description',
    'close_language' => 'Close',
    'save_language' => 'Save',
    
    'user_language' => 'User',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'message2_language' => 'User will permanently be deleted!',
    'continue_language' => 'Continue?',
    'cancel_language' => 'Cancel',
    'delete_language' => 'Delete',
    
    'edit-data_language' => 'Edit Data',
    'priority4_language' => 'Priority',
    'priority5_language' => 'Priority',
    'color4_language' => 'Color',
    'color5_language' => 'Color',
    'desc4_language' => 'Description',
    'desc5_language' => 'Description',
    'save2_language' => 'Save',
    'cancel2_language' => 'Cancel',
    
    
    
  
    ];