<?php

return[
    'validator_language' => 'Site Entry Validator',
    'create_language' => 'Create',
    'site_language' => 'Site',
    'site2_language' => 'Site',
    'validator2_language' => 'Validator I',
    'validator3_language' => 'Validator II',
    
    'new-validator_language' => 'New Validator',
    'site3_language' => 'Site',
    'site4_language' => 'Site',
    'validator4_language' => 'Validator',
    'validator5_language' => 'Validator I',
    'select_language' => 'Select',
    'validator6_language' => 'Validator II',
    'select2_language' => 'Select',
    'save_language' => 'Save',
    'close_language' => 'Close',
    
    'edit-validator_language' => 'Edit Validator',
    'site5_language' => 'Site',
    'site6_language' => 'Site',
    'validator7_language' => 'Validator',
    'validator8_language' => 'Validator I',
    'select3_language' => 'Select',
    'validator9_language' => 'Validator II',
    'select4_language' => 'Select',
    'save2_language' => 'Save',
    'close2_language' => 'Close',
    
    'delete_language' => 'Delete',
    'message_language' => 'Data will be deleted permanently',
    'continue_language' => 'Continue?',
    'close3_language' => 'Close',
    'ok_language' => 'OK'

  
    ];