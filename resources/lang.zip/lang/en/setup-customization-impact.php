<?php

return[
    'impact_language' => 'Impact',
    'new-impact_language' => 'New Impact',
    'name_language' => 'Name',
    'desc_language' => 'Description',
    'message_language' => 'No data available',
    'new-impact2_language' => 'New Impact',
    'impact2_language' => 'Impact',
    'impact3_language' => 'Impact',
    'desc3_language' => 'Description',
    'desc4_language' => 'Description',
    'close_language' => 'Close',
    'save_language' => 'Save',
    
    'edit-data_language' => 'Edit Data',
    'impact4_language' => 'Impact',
    'impact5_language' => 'Impact',
    'desc5_language' => 'Description',
    'desc6_language' => 'Description',
    'save2_language' => 'Save',
    'cancel_language' => 'Cancel',
    
    'user_language' => 'User',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'message2_language' => 'User will permanently be deleted!',
    'continue_language' => 'Continue?',
    'cancel2_language' => 'Cancel',
    'delete_language' => 'Delete',
    
    
    
  
    ];