<?php

return[
    'template_language' => 'Template',
    'new-template_language' => 'New Template',
    'template-add-ons_language' => 'Template Add Ons',
    'name_language' => 'Name',
    'created-by_language' => 'Created By',
    ];