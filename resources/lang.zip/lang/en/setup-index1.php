<?php

return[
    'setup_language' => 'Setup',
    'servicedesk_language' => 'Servicedesk Configuration',
    'servicedesk-desc_language' => 'Instance Setting, Region, Site, Root Caused, and Status',
    'user-permissions_language' => 'User Permissions',
    'user-permissions-desc_language' => 'Role, Technicians, Group Internal, Group External, Task Validator, Site Entry Validator, Aktivasi Validator, and Customer',
    'setting-notification_language' => 'Setting Notifications',
    'setting-notification-desc_language' => 'Setting Notifications Descriptions',
    'customization_language' => 'Customization',
    'customization-desc_language' => 'Category, New Sub Category, New Item, Impact, Priority, Status, and Checklist',
    'template-and-form_language' => 'Templates and Forms',
    'template-and-form-desc_language' => 'Template CM Task, Template PM Task, Template PLM Task, and Template CR Task',
    'data-administration_language' => 'Data Administration',
    'data-administration-desc_language' => 'Data Administration Description',
    'chat_language' => 'Chat',
    'chat-desc_language' => 'Chat Description'
    
    ];