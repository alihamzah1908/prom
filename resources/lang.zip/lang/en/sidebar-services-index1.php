<?php

return[
    'create_language' => 'Create',
    'activation-type_language' => 'Activation Type',
    'customer_language' => 'Customer',
    'select-region_language' => 'Select Region',
    'select-segment_language' => 'Select Segment',
    'refresh_language' => 'Refresh',
    'search_language' => 'Search',
    'activity-no_language' => 'Activity No',
    'customer-name_language' => 'Customer Name',
    'project-name_language' => 'Project Name',
    'type-of-service-from_language' => 'Type of Service',
    'status_language' => 'Status',
    
    
    ];