<?php

return[
    'switch_language' => 'English',
    'judul_language' => 'PALAPA RING OPERATION & MAINTENEANCE',
    'profile_language' => 'Profile',
    'logout_language' => 'Logout'
    ];