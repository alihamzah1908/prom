<?php

return[
    'group-internal_language' => 'Group Internal',
    'new-group_language' => 'New Group',
    'new-user_language' => 'New User',
    'name_language' => 'Name',
    'desc_language' => 'Description',
    'new-group2_language' => 'New Group',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'desc2_language' => 'Description',
    'desc3_language' => 'Description',
    'submit_language' => 'Submit',
    'close_language' => 'Close',
    
    'new-customer_language' => 'New Customer',
    'group_language' => 'Group',
    'group2_language' => 'Group',
    'name4_language' => 'Name',
    'select-customer_language' => 'Select Customer',
    'save_language' => 'Save',
    'close2_language' => 'Close',
    
    'name5_language' => 'Name',
    'email_language' => 'Email'
    

  
    ];