<?php

return[
    'validator_language' => 'Task Validator',
    'create_language' => 'Create',
    'region_language' => 'Region',
    'task-type_language' => 'Task Type',
    'region2_language' => 'Region',
    'task-type2_language' => 'Task Type',
    'layer-validator_language' => 'Validator Layer',
    'validator2_language' => 'Validator',
    
    'new-validator_language' => 'New Validator',
    'region3_language' => 'Region',
    'region4_language' => 'Region',
    'task-type3_language' => 'Task Type',
    'task-type4_language' => 'Task Type',
    'validator3_language' => 'Validator',
    'layer_language' => 'Layer 1',
    'select_language' => 'Select',
    'save_language' => 'Save',
    'cancel_language' => 'Cancel',
    
    'edit-validator_language' => 'Edit Validator',
    'region5_language' => 'Region',
    'region6-data_language' => 'Region',
    'task-type5_language' => 'Task Type',
    'task-type6_language' => 'Task Type',
    'validator4_language' => 'Validator',
    'layer2_language' => 'Layer 1',
    'select2_language' => 'Select',
    'save2_language' => 'Save',
    'cancel2_language' => 'Cancel',
    
    'delete_language' => 'Delete',
    'message_language' => 'Data will be deleted permanently',
    'continue_language' => 'Continue?',
    'close_language' => 'Close',
    'ok_language' => 'OK',
    
    'select3_language' => 'Select',
    'select4_language' => 'Select',
    'select5_language' => 'Select'

  
    ];