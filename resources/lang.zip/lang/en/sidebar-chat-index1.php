<?php

return[
    'inboxs_language' => 'Inboxs',
    'empty_language' => 'Cant send empty chat!'
    ];