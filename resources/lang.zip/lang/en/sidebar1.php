<?php

return[
    
    'dasboard_language' => 'Dashboard',
    'task_language' => 'Task',
    'layanan_language' => 'Services',
    'site-permit_language' => 'Site Permit',
    'regional-gps_language' => 'Regional GPS',
    'user_language' => 'User',
    'waiting-approval_language' => 'Waiting Approval',
    'new_language' => 'New',
    'task2_language' => 'Task',
    'aktivasi_language' => 'Activation',
    'site-permit2_language' => 'Site Permit',
    'task-chats_language' => 'Task Chats',
    'report_language' => 'Report',
    'task-report_language' => 'Task Report',
    'aktivasi-report_language' => 'Report Activation',
    'site-entry-report_language' => 'Site Entry Report',
    'permit-letter-report_language' => 'Permit Letter Report',
    'logout_language' => 'Logout',
    'login_language' => 'Login'
    
    ];