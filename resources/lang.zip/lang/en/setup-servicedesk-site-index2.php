<?php

return[
    'site_language' => 'Site',
    'new-site_language' => 'New Site',
    'sid_language' => 'SID',
    'site-name_language' => 'Site Name',
    'region-name_language' => 'Region Name',
    'site-category_language' => 'Site Category',
    'site-description_language' => 'Site Description',
    'new-site_language' => 'New Site',
    'sid2_language' => 'SID',
    'uid_language' => 'UID',
    'site-name2_language' => 'Site Name',
    'name_language' => 'Name',
    'region-name2_language' => 'Region Name',
    'site-category-name_language' => 'Site Category Name',
    'head-manager_language' => 'Head Manager',
    'address_language' => 'Address',
    'place-your-address_language' => 'Place your Address',
    'desc_language' => 'Description',
    'place-your-desc_language' => 'Place your description',
    'save_language' => 'Save',
    'cancel_language' => 'Cancel',
    'ask_language' => 'Are you sure delete ',
    'notif_language' => 'This record and it`s details will be permanantly deleted!',
    'cancel2_language' => 'Cancel',
    'yes_language' => 'Yes!',
    'message_language' => 'Data has been deleted!'

    ];