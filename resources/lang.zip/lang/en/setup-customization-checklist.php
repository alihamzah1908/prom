<?php

return[
    'checklist_language' => 'Checklist',
    'new-checklist_language' => 'New Checklist',
    'new-category_language' => 'New Category',
    'new-periode_language' => 'New Periode',
    'region_language' => 'Region',
    'all_language' => 'ALL',
    'periode_language' => 'Periode',
    'all2_language' => 'ALL',
    'category_language' => 'Category',
    'all3_language' => 'ALL',
    'id_language' => 'ID',
    'name_language' => 'Name',
    'category2_language' => 'Category',
    'periode2_language' => 'Periode',
    'region2_language' => 'Region',
    'new-checklist2_language' => 'New Checklist',
    'periode3_language' => 'Periode',
    'select-periode_language' => 'Select Periode',
    'category3_language' => 'Category',
    'select-category_language' => 'Select Category',
    'region3_language' => 'Region',
    'select-region_language' => 'Select Region',
    'name2_language' => 'Name',
    'name3_language' => 'Name',
    'close_language' => 'Close',
    'save_language' => 'Save',
    
    'update_language' => 'Update Checklist',
    'periode4_language' => 'Periode',
    'category3_language' => 'Category',
    'region4_language' => 'Region',
    'name4_language' => 'Name',
    'name5_language' => 'Name',
    'close2_language' => 'Close',
    'save2_language' => 'Save',
    
    'name-checklist-category_language' => 'New Checklist Category',
    'name6_language' => 'Name',
    'name7_language' => 'Name',
    'close3_language' => 'Close',
    'save3_language' => 'Save',
    
    'new-checklist-periode_language' => 'New Checklist Periode',
    'name8_language' => 'Name',
    'name9_language' => 'Name',
    'close4_language' => 'Close',
    'save4_language' => 'Save',
    
    'checklist2_language' => 'Checklist',
    'name-checklist_language' => 'Name Checklist',
    'message_language' => 'User will permanently be deleted!',
    'continue_language' => 'Continue?',
    'cancel_language' => 'Cancel',
    'delete_language' => 'Delete',
    
    
    
    
  
    ];