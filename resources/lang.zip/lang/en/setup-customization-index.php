<?php

return[
    'type-task_language' => 'Type Tasks',
    'select-type-task_language' => 'Select Type Task',
    'services-activation_language' => 'Services Activation',
    'next_language' => 'Next'
    ];