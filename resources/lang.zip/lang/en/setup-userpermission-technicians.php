<?php

return[
    'technicians_language' => 'Technicians',
    'new-technician_language' => 'New Technician',
    'name_language' => 'Name',
    'login-name_language' => 'Login Name',
    'email_language' => 'Email',
    'departement-name_language' => 'Departement Name',
    'employe-id_language' => 'Employe ID',
    'new-technician2_language' => 'New Technician',
    'name-technician_language' => 'Name Technician',
    'name-technician2_language' => 'Name Technician',
    'user_language' => 'User',
    'user2_language' => 'User',
    'region_language' => 'Region',
    'region2_language' => 'Region',
    'cancel_language' => 'Cancel',
    'save_language' => 'Save',

  
    ];