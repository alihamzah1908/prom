<?php

return[
    'instance-settings_language' => 'Instance Settings',
    'pt_language' => 'PT. Len Telekominikasi Indonesia',
    'palapa_language' => 'Middle Palapa Ring',
    'url-name_language' => 'Url Name',
    'time-zone_language' => 'Time Zone',
    'owner_language' => 'Owner',
    'access-permissions_language' => 'Access Permissions',
    'currency_language' => 'Currency',
    'start-day-of-the-week_language' => 'Start day of the week'
    ];