<?php

return[
    'lists_language' => 'Lists',
    'create_language' => 'Create',
    'site_language' => 'Site',
    'region_language' => 'Region',
    'site-entry_language' => 'Site Entry',
    'permit-letter_language' => 'Permit Letter',
    'search_language' => 'Search',
    'add_language' => 'Add',
    'create-activity_language' => 'Create Activity',
    'select_language' => 'Select',
    'site-entry2_language' => 'Site Entry',
    'permit-letter2_language' => 'Permit Letter',
    'id_language' => 'ID',
    'name-user-id_language' => 'Name User ID',
    'status_language' => 'Status',
    'situs_language' => 'Site',
    'check-in-time_language' => 'Check In Time',
    'checkout-time_language' => 'Checkout Time',
    'deskripsi_language' => 'Description',
    'id2_language' => 'ID',
    'activity-no_language' => 'Activity No',
    'site2_language' => 'Site',
    'applicant_language' => 'Applicant',
    'date-of-filing_language' => 'Date of filing',
    'status_language' => 'Status',
    'deskripsi2_language' => 'Description'
    
    
    ];