<?php

return[
    'activation-type_language' => 'Activation Type',
    'customer_language' => 'Customer',
    'select-region_language' => 'Select Region',
    'refresh_language' => 'Refresh',
    'search_language' => 'Search',
    'no_language' => 'No',
    'activity-no_language' => 'Activity No',
    'customer-name_language' => 'Customer Name',
    'project-name_language' => 'Project Name',
    'type-of-service_language' => 'Type of Service',
    'status_language' => 'Status'

    ];