<?php

return[
    'task-type_language' => 'Tipe Tugas',
    'region_language' => 'Wilayah',
    'search_language' => 'Cari',
    'creation-time-from_language' => 'Waktu pembuatan dari',
    'to_language' => 'sampai',
    'completion-time-from_language' => 'Waktu penyelesaian dari',
    'to2_language' => 'sampai',
    'refresh_language' => 'Segarkan',
    'download_language' => 'Unduh',
    'task-status_language' => 'Status Tugas',
    'task-id_language' => 'ID Tugas',
    'title_language' => 'Judul',
    'site-id_language' => 'ID Situs',
    'creation-time_language' => 'Waktu Pembuatan',
    'completion-time_language' => 'Waktu Penyelesaian',

    ];