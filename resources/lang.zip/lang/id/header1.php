<?php

return[
    'switch_language' => 'Indonesia',
    'judul_language' => 'PALAPA RING OPERATION & MAINTENANCE',
    'profile_language' => 'Profil',
    'logout_language' => 'Keluar'
    ];