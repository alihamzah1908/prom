<?php

return[
    'customer_language' => 'Pelanggan',
    'new-customer_language' => 'Pelanggan Baru',
    'id_language' => 'ID',
    'name_language' => 'Nama',
    'email_language' => 'Email',
    'new-customer2_language' => 'Pelanggan Baru',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'email2_language' => 'Email',
    'email3_language' => 'Email',
    'save_language' => 'Simpan',
    'close_language' => 'Tutup',
    
    'edit-customer_language' => 'Edit Pelanggan',
    'name4_language' => 'Nama',
    'name5_language' => 'Nama',
    'email4_language' => 'Email',
    'email5_language' => 'Email',
    'save2_language' => 'Simpan',
    'close2_language' => 'Tutup',
    
    'delete_language' => 'Hapus',
    'message_language' => 'Data akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',
    'close3_language' => 'Tutup',
    'ok_language' => 'OK'

  
    ];