<?php

return[
    
    'dasboard_language' => 'Dasboard',
    'task_language' => 'Tugas',
    'layanan_language' => 'Layanan',
    'site-permit_language' => 'Izin Situs',
    'regional-gps_language' => 'GPS Regional',
    'user_language' => 'Pengguna',
    'waiting-approval_language' => 'Menunggu Persetujuan',
    'new_language' => 'Baru',
    'task2_language' => 'Tugas',
    'aktivasi_language' => 'Aktivasi',
    'site-permit2_language' => 'Izin Situs',
    'task-chats_language' => 'Obrolan Tugas',
    'report_language' => 'Laporan',
    'task-report_language' => 'Laporan Tugas',
    'aktivasi-report_language' => 'Aktivasi Laporan',
    'site-entry-report_language' => 'Laporan Entri Situs',
    'permit-letter-report_language' => 'Laporan Surat Izin',
    'logout_language' => 'Keluar',
    'login_language' => 'Masuk'
    
    ];