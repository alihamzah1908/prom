<?php

return[
    'title_language' => 'Konfigurasi Aktivasi Layanan',
    'cord_language' => 'Kord',
    'cid_language' => 'CID',
    'slot_language' => 'Slot',
    'shelf_language' => 'Rak',
    'service-status_language' => 'Status pelayanan',
    'status-collocation_language' => 'Kolokasi Status',
    'services_language' => 'Layanan',
    'total-capacity_language' => 'Total Kapasitas'

  
    ];