<?php

return[
    'priority_language' => 'Prioritas',
    'status_language' => 'Status',
    'root-case_language' => 'Akar Kasus',
    'this-week_language' => 'Minggu Ini',
    'this-month_language' => 'Bulan Ini',
    'count-per-region_language' => 'Hitungan per Wilayah',
    'fo-link-frequency_language' => 'Fo link Frekuensi',
    'chart-mmtr_language' => 'Bagan MMTR',
    
    
    ];