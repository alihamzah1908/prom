<?php

return[
    'impact_language' => 'Dampak',
    'new-impact_language' => 'Dampak Baru',
    'name_language' => 'Nama',
    'desc_language' => 'Deskripsi',
    'message_language' => 'Tidak Ada Data Tersedia',
    'new-impact2_language' => 'Dampak Baru',
    'impact2_language' => 'Dampak',
    'impact3_language' => 'Dampak',
    'desc3_language' => 'Deskripsi',
    'desc4_language' => 'Deskripsi',
    'close_language' => 'Tutup',
    'save_language' => 'Simpan',
    
    'edit-data_language' => 'Edit Data',
    'impact4_language' => 'Dampak',
    'impact5_language' => 'Dampak',
    'desc5_language' => 'Deskripsi',
    'desc6_language' => 'Deskripsi',
    'save2_language' => 'Simpan',
    'cancel_language' => 'Batalkan',
    
    'user_language' => 'Pengguna',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'message2_language' => 'Pengguna akan dihapus secara permanen',
    'continue_language' => 'Lanjutkan?',
    'cancel2_language' => 'Batalkan',
    'delete_language' => 'Hapus'
    
    
    
  
    ];