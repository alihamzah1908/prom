<?php

return[
    'title_language' => 'Layanan',
    'create_language' => 'Buat',
    'name_language' => 'Nama',
    'desc_language' => 'Deskripsi',
    'new-data_language' => 'Layanan Baru',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'desc2_language' => 'Deskripsi',
    'desc3_language' => 'Deskripsi',
    'save_language' => 'Simpan',
    'cancel_language' => 'Batalkan',
    
    'edit-data_language' => 'Edit Layanan',
    'name4_language' => 'Nama',
    'name5_language' => 'Nama',
    'desc4_language' => 'Deskripsi',
    'desc5_language' => 'Deskripsi',
    'save2_language' => 'Simpan',
    'cancel2_language' => 'Batalkan',
    
    
    'data_language' => 'Layanan',
    'name6_language' => 'Nama',
    'name7-data_language' => 'Nama',
    'message_language' => 'Pengguna akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',
    'cancel3_language' => 'Batalkan',
    'delete_language' => 'Hapus'

  
    ];