<?php

return[
    'service-desk_language' => 'Konfigurasi Meja pelayanan',
    'customization_language' => 'Kustomisasi',
    'template-form_language' => 'Formulir Template',
    'users-permissions_language' => 'Pengguna & Izin',
    'service-activation_language' => 'Aktivasi Layanan',
    'setting-notifications_language' => 'Mengatur Notifikasi',
    'data-administration_language' => 'Administrasi Data',
    'chat_language' => 'Obrolan'
];