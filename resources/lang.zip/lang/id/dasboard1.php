<?php

return[
    'dasboard_language' => 'Dasboard',
    'task_language' => 'TUGAS',
    'layanan_language' => 'LAYANAN',
    'site-entry_language' => 'SITUS MASUK',
    'permit-letter_language' => 'SURAT IZIN'
    
    ];