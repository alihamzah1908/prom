<?php

return[
    'site_language' => 'Situs',
    'site-entry_language' => 'Situs Masuk',
    'permit-letter_language' => 'Surat Izin',
    'refresh_language' => 'Segarkan',
    'search_language' => 'Cari',
    'id_language' => 'ID',
    'status_language' => 'Status',
    'region_language' => 'Wilayah',
    'site2_language' => 'Situs',
    'time_language' => 'Waktu',
    'officer_language' => 'Petugas',
    'created-by_language' => 'Dibuat oleh',
    'id2_language' => 'ID',
    'activity-no_language' => 'No Aktivitas',
    'site3_language' => 'Situs',
    'applicant_language' => 'Pemohon',
    'date-of-filing_language' => 'Tanggal Pengajuan',
    'status2_language' => 'Status'
    
    ];