<?php

return[
    'instance-settings_language' => 'Pengaturan Instansi',
    'pt_language' => 'PT. Len Telekominikasi Indonesia',
    'palapa_language' => 'Palapa Ring Tengah',
    'url-name_language' => 'Nama Url',
    'type_language' => 'Tipe',
    'time-zone_language' => 'Zona Waktu',
    'owner_language' => 'Pemilik',
    'access-permissions_language' => 'Izin Akses',
    'currency_language' => 'Mata Uang',
    'start-day-of-the-week_language' => 'Mulai Hari Dalam Seminggu'
    ];