<?php

return[
    'validator_language' => 'Aktivasi Validator',
    'create_language' => 'Buat',
    'region_language' => 'Wilayah',
    'region2_language' => 'Wilayah',
    'type_language' => 'Tipe',
    'validator2_language' => 'Validator I',
    'validator3_language' => 'Validator II',
    'validator10_language' => 'Validator III',
    
    'new-validator_language' => 'Validator Baru',
    'region3_language' => 'Wilayah',
    'region4_language' => 'Wilayah',
    'type2_language' => 'Tipe',
    'type3_language' => 'Tipe Tugas',
    'validator4_language' => 'Validator',
    'validator5_language' => 'Validator I',
    'select_language' => 'Pilih',
    'validator6_language' => 'Validator II',
    'select2_language' => 'Pilih',
    'validator11_language' => 'Validator II',
    'select6_language' => 'Pilih',
    'save_language' => 'Simpan',
    'close_language' => 'Tutup',
    
    'edit-validator_language' => 'Edit Validator',
    'region5_language' => 'Wilayah',
    'region6_language' => 'Wilayah',
    'type4_language' => 'Tipe',
    'type5_language' => 'Tipe Tugas',
    'validator7_language' => 'Validator',
    'validator8_language' => 'Validator I',
    'select3_language' => 'Pilih',
    'validator9_language' => 'Validator II',
    'select4_language' => 'Pilih',
    'validator12_language' => 'Validator II',
    'select5_language' => 'Pilih',
    'save2_language' => 'Simpan',
    'close2_language' => 'Tutup',
    
    'delete_language' => 'Hapus',
    'message_language' => 'Data akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',
    'close3_language' => 'Tutup',
    'ok_language' => 'OK'

  
    ];