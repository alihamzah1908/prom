<?php

return[
    'create_language' => 'Buat',
    'activation-type_language' => 'Tipe Aktivasi',
    'customer_language' => 'Pelanggan',
    'select-region_language' => 'Pilih Wilayah',
    'select-segment_language' => 'Pilih Segmen',
    'refresh_language' => 'Segarkan',
    'search_language' => 'Cari',
    'activity-no_language' => 'Nomor Aktivitas',
    'customer-name_language' => 'Nama Pelanggan',
    'project-name_language' => 'Nama Proyek',
    'type-of-service-from_language' => 'Jenis Layanan',
    'status_language' => 'Status',
    
    
    ];