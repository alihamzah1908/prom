<?php

return[
    'lists_language' => 'Daftar', 
    'create_language' => 'Buat',
    'site_language' => 'Situs',
    'region_language' => 'Wilayah',
    'site-entry_language' => 'Situs Masuk',
    'permit-letter_language' => 'Surat Izin',
    'search_language' => 'Cari',
    'add_language' => 'Tambahkan',
    'create-activity_language' => 'Buat Aktivitas',
    'select_language' => 'Pilih',
    'site-entry2_language' => 'Situs Masuk',
    'permit-letter2_language' => 'Surat Izin',
    'id_language' => 'ID',
    'name-user-id_language' => 'Nama ID Pengguna',
    'status_language' => 'Status',
    'situs_language' => 'Situs',
    'check-in-time_language' => 'Waktu Check In',
    'checkout-time_language' => 'Waktu check out',
    'deskripsi_language' => 'Deskripsi',
    'id2_language' => 'ID',
    'activity-no_language' => 'No Aktivitas',
    'site2_language' => 'Situs',
    'applicant_language' => 'Pemohon',
    'date-of-filing_language' => 'Tanggal Pengajuan',
    'status_language' => 'Status',
    'deskripsi2_language' => 'Deskripsi'
    
    
    ];