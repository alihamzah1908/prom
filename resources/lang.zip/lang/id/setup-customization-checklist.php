<?php

return[
    'checklist_language' => 'Daftar Periksa',
    'new-checklist_language' => 'Daftar Periksa Baru',
    'new-category_language' => 'Kategori Baru',
    'new-periode_language' => 'Periode Baru',
    'region_language' => 'Wilayah',
    'all_language' => 'SEMUA',
    'periode_language' => 'Periode',
    'all2_language' => 'SEMUA',
    'category_language' => 'Kategori',
    'all3_language' => 'SEMUA',
    'id_language' => 'ID',
    'name_language' => 'Nama',
    'category2_language' => 'Kategori',
    'periode2_language' => 'Periode',
    'region2_language' => 'Wilayah',
    'new-checklist2_language' => 'Daftar Periksa Baru',
    'periode3_language' => 'Periode',
    'select-periode_language' => 'Pilih Periode',
    'category3_language' => 'Kategori',
    'select-category_language' => 'Pilih Kategori',
    'region3_language' => 'Wilayah',
    'select-region_language' => 'Pilih Wilayah',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'close_language' => 'Tutup',
    'save_language' => 'Simpan',
    
    'update_language' => 'Perbaharui Daftar Periksa',
    'periode4_language' => 'Periode',
    'category3_language' => 'Kategori',
    'region4_language' => 'Wilayah',
    'name4_language' => 'Nama',
    'name5_language' => 'Nama',
    'close2_language' => 'Tutup',
    'save2_language' => 'Simpan',
    
    'name-checklist-category_language' => 'Daftar Periksa Kategori Baru',
    'name6_language' => 'Nama',
    'name7_language' => 'Nama',
    'close3_language' => 'Tutup',
    'save3_language' => 'Simpan',
    
    'new-checklist-periode_language' => 'Daftar Periksa Periode Baru',
    'name8_language' => 'Nama',
    'name9_language' => 'Nama',
    'close4_language' => 'Tutup',
    'save4_language' => 'Simpan',
    
    'checklist2_language' => 'Daftar Periksa',
    'name-checklist_language' => 'Nama Daftar Periksa',
    'message_language' => 'Pengguna akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',
    'cancel_language' => 'Batalkan',
    'delete_language' => 'Hapus',
    
    
    
    
  
    ];