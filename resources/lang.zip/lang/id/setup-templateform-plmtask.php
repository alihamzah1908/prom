<?php

return[
    'reset-form_language' => 'Atur Ulang',
    
    'basic-information_language' => 'Informasi Dasar',
    'site-id_language' => 'ID Situs',
    'select-site_language' => 'Pilih Situs',
    'task-category_language' => 'Kategori Tugas',
    'select-category_language' => 'Pilih Kategori',
    'task-sub-category_language' => 'Pilih Kategori Bagian',
    'request-start-time_language' => 'Permintaan Waktu Mulai',
    'request-completion_language' => 'Permintaan Penyelesaian',
    'title_language' => 'Judul',
    'subject_language' => 'Subjek',
    'description_language' => 'Deskripsi',
    'description2_language' => 'Deskripsi',
    'technician_language' => 'Teknisi',
    'select-technician_language' => 'Pilih Teknisi',
    'site-information_language' => 'Informasi Situs',
    'site-name_language' => 'Nama Situs',
    'site-address_language' => 'Alamat Situs',
    'region-manager_language' => 'Manajer Wilayah',
    'manager-phone-no_language' => 'No Telepon Manajer',
    'region_language' => 'Wilayah',
    'select-sub-category_language' => 'Pilih Kategori bagian'
    ];