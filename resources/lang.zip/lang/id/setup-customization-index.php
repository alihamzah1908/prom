<?php

return[
    'type-task_language' => 'Tipe Tugas',
    'select-type-task_language' => 'Pilih Tipe Tugas',
    'services-activation_language' => 'Aktivitas Layanan',
    'next_language' => 'Lanjut'
  
    ];