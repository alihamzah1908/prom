<?php

return[
    'template_language' => 'Template',
    'new-template_language' => 'Template Baru',
    'template-add-ons_language' => 'Template Add Ons',
    'name_language' => 'Nama',
    'created-by_language' => 'Dibuat Oleh',
    ];