<?php

return[
    'gps_language' => 'GPS',
    'select-site_language' => 'Pilih Situs',
    'list_language' => 'DAFTAR',
    'map_language' => 'PETA',
    'refresh_language' => 'Segarkan',
    'search_language' => 'Cari',
    'id_language' => 'ID',
    'technician_language' => 'Teknisi',
    'site_language' => 'Situs',
    'latitude_language' => 'Garis Lintang',
    'longitude_language' => 'Garis bujur',
    'last-update_language' => 'Pembaharuan Terakhir',
    
    
    ];