<?php

return[
    'template_language' => 'Template',
    'copy-from_language' => 'Salin dari: ',
    'copy-template_language' => 'Salin Template',
    'template-name_language' => 'Nama Template',
    'template-name2_language' => 'Nama Template',
    'comments_language' => 'Komentar',
    'comments2_language' => 'Komentar',
    'elements_language' => 'Elemen',
    'back_language' => 'Kembali',
    'save-template_language' => 'Simpan Template',
    'field-set_language' => 'Tetapkan Field',
    'field-id_language' => 'ID Field',
    'field-type_language' => 'Tipe Field',
    'field-name_language' => 'Nama Field',
    'field-name2_language' => 'Nama Field',
    'default-value_language' => 'Nilai Default',
    'default-value2_language' => 'Nilai Default',
    'close_language' => 'Tutup',
    'save_language' => 'Simpan'
    
    ];