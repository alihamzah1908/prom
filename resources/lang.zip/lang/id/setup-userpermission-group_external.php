<?php

return[
    'group-external_language' => 'Grup Eksternal',
    'new-group_language' => 'Grup Baru',
    'new-user_language' => 'Pengguna Baru',
    'name_language' => 'Nama',
    'desc_language' => 'Deskripsi',
    'new-group2_language' => 'Grup Baru',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'desc2_language' => 'Deskripsi',
    'desc3_language' => 'Deskripsi',
    'submit_language' => 'Kirim',
    'close_language' => 'Tutup',
    
    'new-customer_language' => 'Pelanggan Baru',
    'group_language' => 'Grup',
    'group2_language' => 'Grup',
    'name4_language' => 'Nama',
    'select-customer_language' => 'Pilih Pelanggan',
    'save_language' => 'Simpan',
    'close2_language' => 'Tutup',
    
    'name5_language' => 'Nama',
    'email_language' => 'Email'
    

  
    ];