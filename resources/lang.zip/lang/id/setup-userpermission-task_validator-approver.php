<?php

return[
    'validator_language' => 'Validator Tugas',
    'create_language' => 'Buat',
    'region_language' => 'Wilayah',
    'task-type_language' => 'Tipe Tugas',
    'region2_language' => 'Wilayah',
    'task-type2_language' => 'Tipe Tugas',
    'layer-validator_language' => 'Lapisan Validator',
    'validator2_language' => 'Validator',
    
    'new-validator_language' => 'Validator Baru',
    'region3_language' => 'Wilayah',
    'region4_language' => 'Wilayah',
    'task-type3_language' => 'Tipe Tugas',
    'task-type4_language' => 'Tipe Tugas',
    'validator3_language' => 'Validator',
    'layer_language' => 'Lapisan 1',
    'select_language' => 'Pilih',
    'save_language' => 'Simpan',
    'cancel_language' => 'Batalkan',
    
    'edit-validator_language' => 'Edit Validator',
    'region5_language' => 'Wilayah',
    'region6-data_language' => 'Wilayah',
    'task-type5_language' => 'Tipe Tugas',
    'task-type6_language' => 'Tipe Tugas',
    'validator4_language' => 'Validator',
    'layer2_language' => 'Lapisan 1',
    'select2_language' => 'Pilih',
    'save2_language' => 'Simpan',
    'cancel2_language' => 'Batalkan',
    
    'delete_language' => 'Hapus',
    'message_language' => 'Data akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',
    'close_language' => 'Tutup',
    'ok_language' => 'OK',
    
    'select3_language' => 'Pilih',
    'select4_language' => 'Pilih',
    'select5_language' => 'Pilih'

  
    ];