<?php

return[
    'reset-form_language' => 'Atur Ulang',
    'category_language' => 'Kategori',
    'select-category_language' => 'Pilih Kategori',
    'priority_language' => 'Prioritas',
    'select-priority_language' => 'Pilih Prioritas',
    'region_language' => 'Wilayah',
    'select-region_language' => 'Pilih Wilayah',
    'location-a_language' => 'Lokasi A',
    'select-location_language' => 'Pilih Lokasi',
    'description_language' => 'Deskripsi',
    'description2_language' => 'Deskripsi',
    'attacment_language' => 'Lampiran',
    'change-attachment_language' => 'Ganti Lampiran',
    'message_language' => '(Biarkan Kosong)',
    'work-time_language' => 'Waktu Kerja',
    'request-start-time_language' => 'Permintaan Waktu Mulai',
    'request-completion_language' => 'Permintaan Penyelesaian',
    'work-day-result_language' => 'Total Hari Kerja',
    'assign-to_language' => 'Ditugaskan kepada',
    'select-technician_language' => 'Pilih Teknisi',
    'down-time_language' => 'Waktu Henti',
    'start-time_language' => 'Waktu Mulai',
    'finish-time_language' => 'Waktu Selesai',
    'work-time-result_language' => 'Total Waktu Kerja'
  
    ];