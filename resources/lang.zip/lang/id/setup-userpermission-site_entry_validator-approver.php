<?php

return[
    'validator_language' => 'Validator Situs Masuk',
    'create_language' => 'Buat',
    'site_language' => 'Situs',
    'site2_language' => 'Situs',
    'validator2_language' => 'Validator I',
    'validator3_language' => 'Validator II',
    
    'new-validator_language' => 'Validator Baru',
    'site3_language' => 'Situs',
    'site4_language' => 'Situs',
    'validator4_language' => 'Validator',
    'validator5_language' => 'Validator I',
    'select_language' => 'Pilih',
    'validator6_language' => 'Validator II',
    'select2_language' => 'Pilih',
    'save_language' => 'Simpan',
    'close_language' => 'Tutup',
    
    'edit-validator_language' => 'Edit Validator',
    'site5_language' => 'Situs',
    'site6_language' => 'Situs',
    'validator7_language' => 'Validator',
    'validator8_language' => 'Validator I',
    'select3_language' => 'Pilih',
    'validator9_language' => 'Validator II',
    'select4_language' => 'Pilih',
    'save2_language' => 'Simpan',
    'close2_language' => 'Tutup',
    
    'delete_language' => 'Hapus',
    'message_language' => 'Data akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',
    'close3_language' => 'Tutup',
    'ok_language' => 'OK'

  
    ];