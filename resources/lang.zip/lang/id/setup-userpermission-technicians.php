<?php

return[
    'technicians_language' => 'Teknisi',
    'new-technician_language' => 'Teknisi Baru',
    'name_language' => 'Nama',
    'login-name_language' => 'Nama Login',
    'email_language' => 'Email',
    'departement-name_language' => 'Nama Departemen',
    'employe-id_language' => 'ID Karyawan',
    'new-technician2_language' => 'Teknisi Baru',
    'name-technician_language' => 'Nama Teknisi',
    'name-technician_language' => 'Nama Teknisi',
    'user_language' => 'Pengguna',
    'user2_language' => 'Pengguna',
    'region_language' => 'Wilayah',
    'region2_language' => 'Wilayah',
    'cancel_language' => 'Batalkan',
    'save_language' => 'Simpan',

  
    ];