<?php

return[
    'priority_language' => 'Prioritas',
    'new-priority_language' => 'Prioritas Baru',
    'name_language' => 'Nama',
    'desc_language' => 'Deskripsi',
    'color_language' => 'Warna',
    'message_language' => 'Tidak ada data tersedia',
    'new-priority2_language' => 'Prioritas Baru',
    'priority2_language' => 'Prioritas',
    'priority3_language' => 'Prioritas',
    'color2_language' => 'Warna',
    'color3_language' => 'Warna',
    'desc2_language' => 'Deskripsi',
    'desc3_language' => 'Deskripsi',
    'close_language' => 'Tutup',
    'save_language' => 'Simpan',
    
    'user_language' => 'Pengguna',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'message2_language' => 'Pengguna akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',
    'cancel_language' => 'Batalkan',
    'delete_language' => 'Hapus',
    
    'edit-data_language' => 'Edit Data',
    'priority4_language' => 'Prioritas',
    'priority5_language' => 'Prioritas',
    'color4_language' => 'Warna',
    'color5_language' => 'Warna',
    'desc4_language' => 'Deskripsi',
    'desc5_language' => 'Deskripsi',
    'save2_language' => 'Simpan',
    'cancel2_language' => 'Batalkan',
    
    
    
  
    ];