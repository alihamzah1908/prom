<?php

return[
    'roles_language' => 'Peran',
    'new-role_language' => 'Peran Baru',
    'role-name_language' => 'Nama Peran',
    'new-role2_language' => 'Peran Baru',
    'name_language' => 'Nama',
    'role-name2_language' => 'Nama Peran',
    'cancel_language' => 'Batalkan',
    'save_language' => 'Simpan',
    'delete_language' => 'Hapus',
    'message_language' => 'Data akan dihapus secara permanen!',
    'continue_language' => 'Lanjutkan?',

    'close_language' => 'Tutup',
    'ok_language' => 'Ok',

  
    ];