<?php

return[
    'footer_language' => 'Semua hak dilindungi.'
    ];