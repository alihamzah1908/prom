<?php

return[
    'root-caused_language' => 'Akar Penyebab',
    'new-root-caused_language' => 'Akbar Penyebab Baru',
    'name_language' => 'Nama',
    'desc_language' => 'Deskripsi',
    'new-root-caused_language' => 'Akar Penyebab Baru',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'desc2_language' => 'Deskripsi',
    'desc3_language' => 'Descripsi',
    'create_language' => 'Buat',
    'cancel_language' => 'Batalkan',
    
    'ask_language' => 'Apkah anda yakin ingin menghapus ',
    'notif_language' => 'Catatan ini beserta detailnya akan dihapus secara permanen!',
    'cancel2_language' => 'Batal',
    'yes_language' => 'Ya!',
    'message_language' => 'Data telah dihapus!'

    ];