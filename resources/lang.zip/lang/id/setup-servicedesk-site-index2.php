<?php

return[
    'site_language' => 'Situs',
    'new-site_language' => 'Situs Baru',
    'sid_language' => 'SID',
    'site-name_language' => 'Nama Situs',
    'region-name_language' => 'Nama Wilayah',
    'site-category_language' => 'Kategori Situs',
    'site-description_language' => 'Situs Deskripsi',
    'new-site_language' => 'Situs Baru',
    'sid2_language' => 'SID',
    'uid_language' => 'UID',
    'site-name2_language' => 'Nama Situs',
    'name_language' => 'Nama',
    'region-name2_language' => 'Nama Wilayah',
    'site-category-name_language' => 'Nama Kategori Situs',
    'head-manager_language' => 'Manajer Kepala',
    'address_language' => 'Alamat',
    'place-your-address_language' => 'Masukkan Alamat',
    'desc_language' => 'Deskripsi',
    'place-your-desc_language' => 'Masukkan Deskripsi',
    'save_language' => 'Simpan',
    'cancel_language' => 'Batal',
    'ask_language' => 'Apkah anda yakin ingin menghapus ',
    'notif_language' => 'Catatan ini beserta detailnya akan dihapus secara permanen!',
    'cancel2_language' => 'Batal',
    'yes_language' => 'Ya!',
    'message_language' => 'Data telah dihapus!'

    ];