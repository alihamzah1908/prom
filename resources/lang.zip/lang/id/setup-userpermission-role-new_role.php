<?php

return[
    'roles_language' => 'Peran',
    'role-name_language' => 'Nama Peran',
    'role-name2_language' => 'Nama Peran',
    'as-admin_language' => 'Sebagai Admin',
    'access_language' => 'Akses',
    'submit_language' => 'Kirim',
    'back_language' => 'Kembali',

  
    ];