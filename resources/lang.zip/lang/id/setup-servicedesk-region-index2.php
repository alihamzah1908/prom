<?php

return[
    'regions_language' => 'Wilayah',
    'new-region_language' => 'Wilayah Baru',
    'region-name_language' => 'Nama Wilayah',
    'desc_language' => 'Deskripsi',
    'new-region2_language' => 'Wilayah Baru',
    'region-name2_language' => 'Nama Wilayah',
    'name_language' => 'Nama',
    'desc2_language' => 'Deskripsi',
    'desc3_language' => 'Deskripsi',
    'create_language' => 'Buat',
    'cancel_language' => 'Batalkan',
    
    'ask_language' => 'Apkah anda yakin ingin menghapus ',
    'notif_language' => 'Catatan ini beserta detailnya akan dihapus secara permanen',
    'cancel2_language' => 'Batalkan',
    'yes_language' => 'Ya!',
    'message_language' => 'Data Berhasil Dihapus'
    ];