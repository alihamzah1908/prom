<?php

return[
    'customers_language' => 'Pelanggan',
    'status_language' => 'Status',
    'used-capacity_language' => 'Kapasitas Terpakai',
    'capacity-1-gb_language' => 'Kapasitas 1 GB',
    'capacity-10-gb_language' => 'Kapasitas 10 GB',
    'this-week_language' => 'Minggu Ini',
    'this-month_language' => 'Bulan Ini',
    'count-per-region_language' => 'Hitungan per Wilayah',
    'count-per-segment_language' => 'Hitung per Segmen',
    'capacity-per-region_language' => 'Kapasitas per Wilayah'
    
    ];