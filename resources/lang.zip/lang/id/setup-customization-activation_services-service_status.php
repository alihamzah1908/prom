<?php

return[
    'title_language' => 'Status',
    
    'name_language' => 'Nama',
    'desc_language' => 'Deskripsi',
    'new-data_language' => 'Status Baru',
    'name2_language' => 'Nama',
    'name3_language' => 'Nama',
    'desc2_language' => 'Deskripsi',
    'desc3_language' => 'Deskripsi',
    'save_language' => 'Simpan',
    'cancel_language' => 'Batalkan',
    
    'edit-data_language' => 'Edit Status',
    'name4_language' => 'Nama',
    'name5_language' => 'Nama',
    'desc4_language' => 'Deskripsi',
    'desc5_language' => 'Deskripsi',
    'save2_language' => 'Simpan',
    'cancel2_language' => 'Batalkan'

  
    ];