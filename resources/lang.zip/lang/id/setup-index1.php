<?php

return[
    'setup_language' => 'Pengaturan Awal',
    'servicedesk_language' => 'Meja pelayanan',
    'servicedesk-desc_language' => 'Pengaturan Instance, Wilayah, Situs, Akar yang Disebabkan, Status',
    'user-permissions_language' => 'Izin Pengguna',
    'user-permissions-desc_language' => 'Peran, Teknisi, Grup Internal, Grup Eksternal, Validator Tugas, Validator Entri Situs, Validator Aktivasi, dan Pelanggan',
    'setting-notification_language' => 'Mengatur Notifikasi',
    'setting-notification-desc_language' => 'Deskripsi Pengaturan Notifikasi',
    'customization_language' => 'Kustomisasi',
    'customization-desc_language' => 'Kategori, Sub Kategori Baru, Item Baru, Dampak, Prioritas, Status, dan Daftar Periksa',
    'template-and-form_language' => 'Template dan Formulir', 
    'template-and-form-desc_language' => 'Tugas Template CM, Tugas Template PM, Tugas Template PLM, dan Tugas Template CR',
    'data-administration_language' => 'Administrasi Data',
    'data-administration-desc_language' => 'Deskripsi Administrasi Data',
    'chat_language' => 'Obrolan',
    'chat-desc_language' => 'Deskripsi Chat'
    
    ];