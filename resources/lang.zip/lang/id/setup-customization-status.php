<?php

return[
    'status_language' => 'Status',
    'new-status_language' => 'Status Baru',
    'name_language' => 'Nama',
    'desc_language' => 'Deskripsi',
    'group_language' => 'Grup',
    'color_language' => 'Warna',
    'message_language' => 'Tidak Ada Data Tersedia',
    'new-status_language' => 'Status Baru',
    'status2_language' => 'Status',
    'status3_language' => 'Status',
    'color2_language' => 'Warna',
    'color3_language' => 'Warna',
    'type_language' => 'Tipe',
    'in-progress_language' => 'Sedang berlangsung',
    'completed_language' => 'Selesai',
    'stop-timer_language' => 'Hentikan Timer',
    'desc2_language' => 'Deskripsi',
    'desc3_language' => 'Deskripsi',
    'save_language' => 'Simpan',
    
    'edit-data_language' => 'Edit Data',
    'status4_language' => 'Status',
    'status5_language' => 'Status',
    'color4_language' => 'Warna',
    'color5_language' => 'Warna',
    'type2_language' => 'Tipe',
    'in-progress2_language' => 'Sedang berlangsung',
    'completed2_language' => 'Selesai',
    'stop-timer2_language' => 'Hentikan Timer',
    'desc4_language' => 'Deskripsi',
    'desc5_language' => 'Deskripsi',
    'save2_language' => 'Simpan',
    'cancel_language' => 'Batalkan'
    
    
    
    
    
  
    ];