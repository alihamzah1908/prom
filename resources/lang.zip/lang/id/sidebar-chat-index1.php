<?php

return[
    'inboxs_language' => 'Kotak masuk',
    'empty_language' => 'Tidak dapat mengirim obrolan kosong!',
    ];