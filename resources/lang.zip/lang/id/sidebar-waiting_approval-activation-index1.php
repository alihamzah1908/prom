<?php

return[
    'activation-type_language' => 'Tipe Aktivasi',
    'customer_language' => 'Pelanggan',
    'select-region_language' => 'Pilih Wilayah',
    'refresh_language' => 'Segarkan',
    'search_language' => 'Cari',
    'no_language' => 'No',
    'activity-no_language' => 'No Aktivitas',
    'customer-name_language' => 'Nama Pelanggan',
    'project-name_language' => 'Nama Proyek',
    'type-of-service_language' => 'Jenis Layanan',
    'status_language' => 'Status'

    ];